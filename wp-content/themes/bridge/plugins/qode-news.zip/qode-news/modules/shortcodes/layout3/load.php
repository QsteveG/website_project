<?php

include_once QODE_NEWS_SHORTCODES_PATH.'/layout3/functions.php';
include_once QODE_NEWS_SHORTCODES_PATH.'/layout3/layout3.php';